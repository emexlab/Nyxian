# TWRP terminal (Nyxian recovery)
export TERM="${TERM:-xterm-256color}"
export PS1='\w # '
# no LANG/LC_*: iOS has no C.UTF-8, and readline 8.2 (_rl_init_locale) does
# strlen(setlocale(LC_CTYPE, $LANG)) without a NULL check -> crash at the next prompt
if [ -z "$NX_RECOVERY_MOTD_SHOWN" ] && [ -t 1 ]; then
    export NX_RECOVERY_MOTD_SHOWN=1
    echo "Nyxian recovery shell. / (and ~) is the binpack, /rootfs is the bootloader's container."
fi
